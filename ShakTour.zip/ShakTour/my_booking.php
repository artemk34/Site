<?
	include "configurations/db.php";
	
	if (isset($_COOKIE[session_name()]))
	{
		session_start();
	}
	else header ("Location: index.php");
	
	if (isset($_GET['exit']) && $_GET['exit']==true)
	{
		$query = "UPDATE users SET Token = NULL WHERE Token = '".$_COOKIE["token"]."'"; 
		$result = mysqli_query($link,$query);
		setcookie(session_name(), "", time()-3600, "/");
		session_destroy;
		header ("Location: index.php");
	}
	
	$query = "SELECT id, isAdmin FROM users WHERE Token = '".$_COOKIE["token"]."'";
	$result = mysqli_query($link,$query);
	$profile =  mysqli_fetch_assoc($result);
	
	$query = "SELECT * FROM booking JOIN tours ON tours.id= id_tour WHERE id_user = ".$profile['id'];
	
	if (isset($_GET['orderBy']) && ($_GET['orderBy'] == "Price" || $_GET['orderBy'] == "Date_start"))
	{
		$query.= " ORDER BY ".$_GET['orderBy']." DESC";
	}
	
	$result = mysqli_query($link,$query);
	$counter = 0;
	while ($line = mysqli_fetch_assoc($result))
	{
		$tours[$counter]=$line;
		$counter++;
	}
	mysqli_close($link);
?>
<!doctype html>
<html>
  <head>
	<link rel="icon" href="./images/logo1.png" type="image/png"> 
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<title>ShakTour</title>
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="style.css" type="text/css"/>
	<style>
* {
  box-sizing: border-box;
}

#myInput {
  background-image: url('./images/Search.jpg');
  background-position: 10px 12px;
  background-repeat: no-repeat;
  width: 750px;
  font-size: 16px;
  padding: 15px 0px 15px 60px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myUL {
  list-style-type: none;
  padding: 0;
  margin: 0;
}

#myUL li a {
  border: 1px solid #ddd;
  margin-top: -1px; /* Prevent double borders */
  background-color: #f6f6f6;
  padding: 12px;
  text-decoration: none;
  font-size: 18px;
  color: black;
  display: block
}

#myUL li a:hover:not(.header) {
  background-color: #eee;
}
</style>
	 </head>
<body>
  <div><a id='top'/></div>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
	<div class="container-fluid">
		<div class="img"><img src="./images/logo.png" height="100" alt="..."></div>
		<div class="collapse navbar-collapse" style="margin-left:100px;" id="navbarSupportedContent">		
			<div class="tel"><a href="index.php">Главная<a></div>
			<div class="tel"><a href="booking.php">Оформить путевку</a></div>
			<div class="tel"><a href="my_booking.php">Мои туры</a></div>
			<?if ($profile['isAdmin'] == 1){?>
			<div class="tel"><a href="adm_panel.php">Административная панель</a></div>
			<?}?>
		</div>
		<div class="collapse navbar-collapse" style="margin-left:700px;" id="navbarSupportedContent">
			<?if (!isset($_COOKIE[session_name()])){?>
				<div class="tel"><a href="authorization.php">Вход</a></div>
				<div class="tel"><a href="registration.php">Регистрация</a></div>
			<?}
			else{?>
				<div class="tel"><a href="?exit=true">Выход</a></div>
			<?}?>
		</div>
    </div>
  </nav>
 <script>
function myFunction() {
    var input, filter, ul, li, a, i, txtValue;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    ul = document.getElementById("myUL");
    li = ul.getElementsByTagName("li");
    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("a")[0];
        txtValue = a.textContent || a.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = "inline-block";
        } else {
            li[i].style.display = "none";
        }
    }
}
function sortListDir() {
  var list, i, switching, b, shouldSwitch, dir, switchcount = 0;
  list = document.getElementById("myUL");
  switching = true;
  // Set the sorting direction to ascending:
  dir = "asc";
  // Make a loop that will continue until no switching has been done:
  while (switching) {
    // Start by saying: no switching is done:
    switching = false;
    b = list.getElementsByTagName("LI");
    // Loop through all list-items:
    for (i = 0; i < (b.length - 1); i++) {
      // Start by saying there should be no switching:
      shouldSwitch = false;
      /* Check if the next item should switch place with the current item,
      based on the sorting direction (asc or desc): */
      if (dir == "asc") {
        if (b[i].innerHTML.toLowerCase() > b[i + 1].innerHTML.toLowerCase()) {
          /* If next item is alphabetically lower than current item,
          mark as a switch and break the loop: */
          shouldSwitch = true;
          break;
        }
      } else if (dir == "desc") {
        if (b[i].innerHTML.toLowerCase() < b[i + 1].innerHTML.toLowerCase()) {
          /* If next item is alphabetically higher than current item,
          mark as a switch and break the loop: */
          shouldSwitch= true;
          break;
        }
      }
    }
    if (shouldSwitch) {
      /* If a switch has been marked, make the switch
      and mark that a switch has been done: */
      b[i].parentNode.insertBefore(b[i + 1], b[i]);
      switching = true;
      // Each time a switch is done, increase switchcount by 1:
      switchcount ++;
    } else {
      /* If no switching has been done AND the direction is "asc",
      set the direction to "desc" and run the while loop again. */
      if (switchcount == 0 && dir == "asc") {
        dir = "desc";
        switching = true;
      }
    }
  }
}
</script>
<div class="Search" style="margin-top:2%; margin-left:16.1%; margin-right:16.1%;">
	<?if(!isset($_GET['tourID'])){?>
	<div class="search1">
	<div><input type="text"  id="myInput" onkeyup="myFunction()" placeholder="Поиск тура" title="Введите название тура"></div>
	<div><button style="border: none; border-radius: 7px; padding: 10px 25px; width:200px; height:60px; margin-right:40px; background: #0099ff; text-transform: uppercase;font-weight: bold; color: white; position: relative; cursor: pointer; margin-bottom:20px;" onclick="window.location.href ='?orderBy=Price'">Сортировать по цене</button></div>
	<div><button style="border: none; border-radius: 7px; padding: 10px 25px; width:200px; height:60px; background: #0099ff; text-transform: uppercase;font-weight: bold; color: white; position: relative; cursor: pointer; margin-bottom:20px;" onclick="window.location.href ='?orderBy=Date_start'">Сортировать по дате выезда</button></div>
	</div>
	<?}?>
<ul id="myUL" style="width:1290px;">
	<?if (!empty($tours)){
		for($i=0; $i < count($tours); $i++){?>
	<li style="display: inline-block; width:319.2px;">
	<div class="Tour" style="height:450px;">
		<div style="height:100%; width:100%;">
			<a href="booking.php?tourID=<?=$tours[$i]['id']?>" style="text-align:center; height:10%; width:100%; background-color:lightblue;"><?=$tours[$i]['Tour']?></a>
			<div style="background-image:url('./images/<?=$tours[$i]['Photo']?>'); width:100%; height:60%; background-size:100% 100%;">
			</div>
			<a href="#" style="text-align:center; width:100%; height:10%; background-color:lightblue;"><?="c ".$tours[$i]['Date_start']." по ".$tours[$i]['Date_end']?></a>
			<a href="#" style="text-align:center; width:100%; height:10%; background-color:lightblue;">Кол-во человек: <?=$tours[$i]['Guests']?></a>
			<a href="#" style="text-align:center; width:100%; height:10%; background-color:lightblue;">Итоговая цена: <?=$tours[$i]['Cost']?> руб.</a>
		</div>
	</div>
	</li>
	<?}}
	else{?>
		<p align=center>Купленных путевок нет</p>
	<?}?>
</ul>
</div>
<br><br><br>
<div><a href="#top" class="idTop">ВВЕРХ</a></div>
<div class="row" style="height:255px; background-color:#2c3136; margin-top:0;">
	<div class="card" style="width: 15rem;transform:none; background-color:#2c3136; margin-top:5%;border:0px;">
		<img src="./images/logo.png" class="card-img-top" alt="...">
	</div>
	<div class="card" style="width: 17rem;transform:none; background-color:#2c3136; height:20%; border:0px; margin-top:5%;">
		<div class="card-body" style="background-color:#2c3136; color:#c59b49; border:0px;">
			<p class="card-text"><img src="./images/address.png" height="25" width="25">Москва, Набережная 2 оф. 142 <br><br><img src="./images/phone.png" height="25" width="25">+7 923 398 9013</p>
		</div>
	</div>
	<div class="card" style="width: 5rem; background-color:#2c3136; height:15%; margin-top:7%;border:0px;">
		<img src="./images/youtube.png" class="card-img-top" alt="..." style="margin-top:-15%;">
	</div>
	<div class="card" style="width: 5rem; background-color:#2c3136; height:15%; margin-top:7%;border:0px;">
		<img src="./images/instagram.png" class="card-img-top" alt="..." style="margin-top:-15%;">
	</div>
	<div class="card" style="width: 5rem; background-color:#2c3136; height:15%; margin-top:7%;border:0px;">
		<img src="./images/vk.png" class="card-img-top" alt="..." style="margin-top:-15%;">
	</div>
	<div style="text-align:center; color:#c59b49; background-color:#2c3136;">2022 © ShakTour</div>
</div>
</body>
</html> 