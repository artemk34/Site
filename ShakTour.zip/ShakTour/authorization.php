<?
	function Authorization($email, $password)
	{
		include "configurations/db.php";
		
		$query = "SELECT Password FROM users WHERE Email = '$email'";

		$result = mysqli_query($link,$query);
		$result = mysqli_fetch_assoc($result);
		
		if (!empty($result))
		{
			if (password_verify($password, $result["Password"]))
			{
				session_start();
				$token = sha1(time());
				setcookie("token",$token);
				$query = "UPDATE users SET Token = '$token' WHERE Email = '$email'"; 
				$result = mysqli_query($link,$query);
				header ("Location: booking.php");
			}
			else 
			{
				return "Неверный пароль";
			}
		}
		else 
		{
			return "Неверный email";
		}
		mysqli_close($link);
	}
	if (!empty($_POST['email']) && !empty($_POST['password']))
	{
		echo "<p align=center>".Authorization($_POST['email'], $_POST['password'])."</p>";
	}
?>
<!doctype html>
<html>
  <head>
	<link rel="icon" href="./images/logo1.png" type="image/png"> 
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<title>ShakTour</title>
	<link rel="stylesheet" href="style.css" type="text/css"/>
  </head>
<body>
  <div><a id='top'/></div>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
	<div class="container-fluid">
		<div class="img"><img src="./images/logo.png" height="100" alt="..."></div>
		<div class="collapse navbar-collapse" style="margin-left:100px;" id="navbarSupportedContent">		
			<div class="tel"><a href="index.php">Главная<a></div>
		</div>
		<div class="collapse navbar-collapse" style="margin-left:700px;" id="navbarSupportedContent">		
			<div class="tel"><a href="#">Вход</a></div>
			<div class="tel"><a href="registration.php">Регистрация</a></div>
		</div>
    </div>
  </nav>
  <h4 style="text-align:center;margin-top:30px; margin-bottom:15px;">Введите ваш email и пароль</h4>
  <p style="text-align:center;">Если вы уже зарегистрированы, <br>пожалуйста, используйте логин и пароль для <br>входа на сайт.</p>
  <form method="POST" action="" style="text-align:center;">
	<p style="margin-right:250px;">E-mail</p>
	<input style="margin-left:auto; margin-right:auto; width:20%" type="email"  placeholder="Введите ваш E-mail" name="email"><br>
	<p style="margin-right:250px; margin-top:15px;">Пароль</p>
	<input style="width:20%" type="password"  placeholder="Введите пароль" name="password"><br>
	<button type="submit" name="auth">Войти</button><br>
  </form>
	<div style="margin-left:auto; margin-right:auto; display:flex; margin-top:20px;">
		<hr style="width:15%; margin-left:32%; border: 2px solid blue;">
		<h5 style="margin-left:2%; margin-right:2%;">Или</h5>
		<hr style="width:15%; border: 2px solid blue;">
	</div>
	<button type="button" name="registration2" onclick="window.location.href ='registration.php'">Зарегистрироваться</button>
  <div class="row" style="height:255px; background-color:#2c3136;">
	<div class="card" style="width: 15rem;transform:none; background-color:#2c3136; margin-top:2%; border:0px;">
		<img src="./images/logo.png" class="card-img-top" alt="...">
	</div>
	<div class="card" style="width: 17rem;transform:none; background-color:#2c3136; height:20%; border:0px; margin-top:5%;">
		<div class="card-body" style="background-color:#2c3136; color:#c59b49; border:0px;">
			<p class="card-text"><img src="./images/address.png" height="25" width="25">Москва, Набережная 2 оф. 142 <br><br><img src="./images/phone.png" height="25" width="25">+7 923 398 9013</p>
		</div>
	</div>
	<div class="card" style="width: 5rem; background-color:#2c3136; height:15%; margin-top:7%;border:0px;">
		<img src="./images/youtube.png" class="card-img-top" alt="..." style="margin-top:-15%;">
	</div>
	<div class="card" style="width: 5rem; background-color:#2c3136; height:15%; margin-top:7%;border:0px;">
		<img src="./images/instagram.png" class="card-img-top" alt="..." style="margin-top:-15%;">
	</div>
	<div class="card" style="width: 5rem; background-color:#2c3136; height:15%; margin-top:7%;border:0px;">
		<img src="./images/vk.png" class="card-img-top" alt="..." style="margin-top:-15%;">
	</div>
	<div style="text-align:center; color:#c59b49; background-color:#2c3136;">2022 © ShakTour</div>
</div>
</body>
</html>