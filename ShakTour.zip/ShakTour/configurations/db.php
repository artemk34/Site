<?
	$dbHostname = "localhost";
	$dbUsername = "root";
	$dbPassword = "";
	$dbName = "team_shaktour";

	$link = mysqli_connect($dbHostname, $dbUsername, $dbPassword, $dbName);
	mysqli_query($link,'SET NAMES utf8');
?>