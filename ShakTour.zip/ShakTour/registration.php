<?
	function Registration($email, $name, $surname, $patronymic, $phone, $password)
	{
		include "configurations/db.php";
		
		$query = "SELECT Email FROM users WHERE Email = '$email'";
		
		$result = mysqli_query($link, $query);
		$result = mysqli_fetch_array($result);
		
		if (empty($result))
		{
			$query = "INSERT INTO users(Email, Password, Surname, Name, Patronymic, Phone) VALUES ('$email','".password_hash($password, PASSWORD_DEFAULT)."','$surname', '$name', '$patronymic', '$phone')";
			$result = mysqli_query($link,$query);
			header ("Location: authorization.php");
		}
		else 
		{
			return "Пользователь с таким email уже существует!";
		}
		
		mysqli_close($link);
	}
	if (!empty($_POST['email']) && !empty($_POST['name']) && !empty($_POST['surname']) && !empty($_POST['patronymic']) && !empty($_POST['phone']) && !empty($_POST['password']))
	{
		echo "<p align=center>".Registration($_POST['email'], $_POST['name'], $_POST['surname'], $_POST['patronymic'], $_POST['phone'], $_POST['password'])."</p>";
	}
?>
<!doctype html>
<html>
  <head>
	<link rel="icon" href="./images/logo1.png" type="image/png"> 
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<title>ShakTour</title>
	<link rel="stylesheet" href="style.css" type="text/css"/>
  </head>
<body>
	<div><a id='top'/></div>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
	<div class="container-fluid">
		<div class="img"><img src="./images/logo.png" height="100" alt="..."></div>
		<div class="collapse navbar-collapse" style="margin-left:100px;" id="navbarSupportedContent">		
			<div class="tel"><a href="index.php">Главная</a></div>
		</div>
		<div class="collapse navbar-collapse" style="margin-left:700px;" id="navbarSupportedContent">		
			<div class="tel"><a href="authorization.php">Вход</a></div>
			<div class="tel"><a href="#">Регистрация</a></div>
		</div>
    </div>
	</nav>
	<h4 style="text-align:center;margin-top:35px; margin-bottom:30px;">Заполните анкету для регистрации в сервисе.</h4>
	<form method="POST" action="" style="text-align:center;">
		<input style="margin-bottom:20px; margin-top:10px; margin-left:auto; margin-right:auto; width:20%" type="text"  placeholder="Введите вашу фамилию" name="surname"><br>
		<input style="margin-bottom:20px; margin-top:10px; width:20%" type="text"  placeholder="Введите ваше имя" name="name"><br>
		<input style="margin-bottom:20px; margin-top:10px; width:20%" type="text"  placeholder="Введите ваше отчество" name="patronymic"><br>
		<input style="margin-bottom:20px; margin-top:10px; margin-left:auto; margin-right:auto; width:20%" type="email"  placeholder="Введите ваш E-mail" name="email"><br>
		<input style="margin-bottom:20px; margin-top:10px; margin-left:auto; margin-right:auto; width:20%" type="tel"  placeholder="Введите ваш номер телефона" name="phone"><br>
		<input style="margin-bottom:20px; margin-top:10px; width:20%" type="password"  placeholder="Введите пароль" name="password"><br>
		<button type="submit" name="registration1">Зарегистрироваться</button><br>
	</form>
	<div class="row" style="height:255px; background-color:#2c3136;">
	<div class="card" style="width: 15rem;transform:none; background-color:#2c3136; margin-top:2%;border:0px;">
		<img src="./images/logo.png" class="card-img-top" alt="...">
	</div>
	<div class="card" style="width: 17rem;transform:none; background-color:#2c3136; height:20%; border:0px; margin-top:5%;">
		<div class="card-body" style="background-color:#2c3136; color:#c59b49; border:0px;">
			<p class="card-text"><img src="./images/address.png" height="25" width="25"> Москва, Набережная 2 оф. 142 <br><br><img src="./images/phone.png" height="25" width="25">+7 923 398 9013</p>
		</div>
	</div>
	<div class="card" style="width: 5rem; background-color:#2c3136; height:15%; margin-top:7%;border:0px;">
		<img src="./images/youtube.png" class="card-img-top" alt="..." style="margin-top:-15%;">
	</div>
	<div class="card" style="width: 5rem; background-color:#2c3136; height:15%; margin-top:7%;border:0px;">
		<img src="./images/instagram.png" class="card-img-top" alt="..." style="margin-top:-15%;">
	</div>
	<div class="card" style="width: 5rem; background-color:#2c3136; height:15%; margin-top:7%;border:0px;">
		<img src="./images/vk.png" class="card-img-top" alt="..." style="margin-top:-15%;">
	</div>
	<div style=" text-align:center; color:#c59b49; background-color:#2c3136;">2022 © ShakTour</div>
</div>
</body>
</html>