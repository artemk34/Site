<?
	include "configurations/db.php";
	if (isset($_COOKIE[session_name()]))
	{
		session_start();
	}
	else header ("Location: index.php");
	if (isset($_GET['exit']) && $_GET['exit']==true)
	{
		$query = "UPDATE users SET Token = NULL WHERE Token = '".$_COOKIE["token"]."'"; 
		$result = mysqli_query($link,$query);
		setcookie(session_name(), "", time()-3600, "/");
		session_destroy;
		header ("Location: index.php");
	}
	
	if (isset($_GET['deleteID']))
	{
		$query = "DELETE FROM tours WHERE id = '".$_GET['deleteID']."'"; 
		$result = mysqli_query($link,$query);
		header ("Location: adm_panel.php");
	}
	
	function translit_sef($value)
	{
		$converter = array(
			'а' => 'a',    'б' => 'b',    'в' => 'v',    'г' => 'g',    'д' => 'd',
			'е' => 'e',    'ё' => 'e',    'ж' => 'zh',   'з' => 'z',    'и' => 'i',
			'й' => 'y',    'к' => 'k',    'л' => 'l',    'м' => 'm',    'н' => 'n',
			'о' => 'o',    'п' => 'p',    'р' => 'r',    'с' => 's',    'т' => 't',
			'у' => 'u',    'ф' => 'f',    'х' => 'h',    'ц' => 'c',    'ч' => 'ch',
			'ш' => 'sh',   'щ' => 'sch',  'ь' => '',     'ы' => 'y',    'ъ' => '',
			'э' => 'e',    'ю' => 'yu',   'я' => 'ya',
		);
	 
		$value = mb_strtolower($value);
		$value = strtr($value, $converter);
		$value = mb_ereg_replace('[^-0-9a-z]', '-', $value);
		$value = mb_ereg_replace('[-]+', '-', $value);
		$value = trim($value, '-');	
	 
		return $value;
	}
	
	function InsertTour($tour, $price, $quantity, $date_start, $date_end, $url)
	{
		if ($date_end > $date_start)
		{
			include "configurations/db.php";
			$query = "SELECT id FROM tours WHERE Name = '$name'";
			$result = mysqli_query($link,$query);
			if (mysqli_num_rows($result) == 0)
			{
				$jpg = file_get_contents($url);
				file_put_contents("images/tour_".translit_sef($tour).".jpg", $jpg);
				$query = "INSERT INTO tours (Tour, Price, Quantity, Date_start, Date_end, Photo) VALUES ('$tour', '$price', '$quantity', '$date_start', '$date_end', 'tour_".translit_sef($tour).".jpg')";
				$result = mysqli_query($link,$query);
				header("Location: adm_panel.php");
			}
			else 
			{
				return "Такой тур уже есть в базе";
			}
		}
		else
		{
			return "Дата начала тура не может быть раньше даты конца тура";
		}
		mysqli_close($link);
	}
	if (!empty($_POST['Tour']) && !empty($_POST['Price']) && !empty($_POST['Quantity']) && !empty($_POST['Date_start']) && !empty($_POST['Date_end']) && !empty($_POST['URL']))
	{
		echo InsertTour( $_POST['Tour'], $_POST['Price'], $_POST['Quantity'], $_POST['Date_start'], $_POST['Date_end'], $_POST['URL']);
	}
	
	if (!empty($_POST['Tour1']) && !empty($_POST['Quantity1'])) 
	{
		$query = "UPDATE tours SET Quantity = ".$_POST['Quantity1']." WHERE id = ".$_POST['Tour1'];
		$result = mysqli_query($link,$query);
		header("Location: adm_panel.php");
	}
	
	$query = "SELECT isAdmin FROM users WHERE Token = '".$_COOKIE["token"]."'";
	$result = mysqli_query($link,$query);
	$profile =  mysqli_fetch_assoc($result);
	
	$query = "SELECT * FROM tours";

	$result = mysqli_query($link,$query);
	$counter = 0;
	while ($line = mysqli_fetch_assoc($result))
	{
		$tours[$counter]=$line;
		$counter++;
	}
	
	mysqli_close($link);
?>
<html>
  <head>
	<link rel="icon" href="./images/logo1.png" type="image/png"> 
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<title>ShakTour</title>
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="style.css" type="text/css"/>
	<style>
* {
  box-sizing: border-box;
}

#myInput {
  background-image: url('./images/Search.jpg');
  background-position: 10px 12px;
  background-repeat: no-repeat;
  width: 750px;
  font-size: 16px;
  padding: 15px 0px 15px 60px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myUL {
  list-style-type: none;
  padding: 0;
  margin: 0;
}

#myUL li a {
  border: 1px solid #ddd;
  margin-top: -1px; /* Prevent double borders */
  background-color: #f6f6f6;
  padding: 12px;
  text-decoration: none;
  font-size: 18px;
  color: black;
  display: block
}

#myUL li a:hover:not(.header) {
  background-color: #eee;
}
</style>
  </head>
<body>
  <div><a id='top'/></div>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
	<div class="container-fluid">
		<div class="img"><img src="./images/logo.png" height="100" alt="..."></div>
		<div class="collapse navbar-collapse" style="margin-left:100px;" id="navbarSupportedContent">		
			<div class="tel"><a href="index.php">Главная</a></div>
			<div class="tel"><a href="booking.php">Оформить путевку</a></div>
			<div class="tel"><a href="my_booking.php">Мои туры</a></div>
			<div class="tel"><a href="adm_panel.php">Административная панель</a></div>
		</div>
		<div class="collapse navbar-collapse" style="margin-left:700px;" id="navbarSupportedContent">
			<?if (!isset($_COOKIE[session_name()])){?>
				<div class="tel"><a href="authorization.php">Вход</a></div>
				<div class="tel"><a href="registration.php">Регистрация</a></div>
			<?}
			else{?>
				<div class="tel"><a href="?exit=true">Выход</a></div>
			<?}?>
		</div>
    </div>
  </nav>
<table class="table table-striped" style="width:100%">
	<thead>
	 <tr>
		<th scope="col">№</th>
		<th scope="col">Название тура</th>
		<th scope="col">Цена</th>
		<th scope="col">Кол-вао оставшихся путевок</th>
		<th scope="col">Дата начала тура</th>
		<th scope="col">Дата окончания тура</th>
		<th scope="col">Фотография</th>
		<th scope="col"></th>
	</tr>
	</thead>
	<tbody>
	<?for($i=0; $i<count($tours); $i++){?>
	<tr>
		<th scope="row"><?=$i+1?></th>
		<td><?=$tours[$i]['Tour']?></td>
		<td><?=$tours[$i]['Price']?></td>
		<td><?=$tours[$i]['Quantity']?></td>
		<td><?=$tours[$i]['Date_start']?></td>
		<td><?=$tours[$i]['Date_end']?></td>
		<td><img src='images/<?=$tours[$i]['Photo']?>' height=150px width=150px></td>
		<td><button type="button" onclick="window.location.href ='?deleteID=<?=$tours[$i]['id']?>'">Удалить запись</button></td>
	</tr>
	<?}?>
	<tbody>
</table>
<h4 style="text-align:center;margin-top:30px; margin-bottom:30px;">Добавить информацию о туре</h4>
  <form style="text-align:center;" method="POST" action="">
	<input style="margin-bottom:20px; width:20%" type="text"  placeholder="Название тура" name="Tour"><br>
	<input style="margin-bottom:20px; width:20%" type="number" min=0  placeholder="Цена тура" name="Price"><br>
	<input style="margin-bottom:20px; width:20%" type="number" min=0 placeholder="Количество путевок" name="Quantity"><br>
	<input type="date" style="margin-bottom:20px; margin-left:auto; margin-right:auto; width:20%" placeholder="Дата начала тура" name="Date_start"><br>
	<input type="date" style="margin-bottom:20px; margin-left:auto; margin-right:auto; width:20%" placeholder="Дата окончания тура" name="Date_end"><br>
	<input type="url" style="margin-bottom:20px; margin-left:auto; margin-right:auto; width:20%"  placeholder="URL картинки" name="URL"><br>
	<button type="submit" name="registration3">Отправить</button><br>
  </form>
 <h4 style="text-align:center;margin-top:30px; margin-bottom:30px;">Обновить количество оставшихся путевок</h4>
  <form style="text-align:center;" method="POST" action="">
	<select style="margin-bottom:20px; margin-left:auto; margin-right:auto; height:20px; width:20%" name="Tour1" style="margin-bottom:20px; width:20%">
		<option selected></option>
		<?
			for($i=0; $i<count($tours); $i++)
			{
				echo "<option value='".$tours[$i]["id"]."'>".$tours[$i]["Tour"]."</option>";
			}
		?>
	</select><br>
	<input style="margin-bottom:20px; width:20%" type="number" min=0 placeholder="Количество путевок" name="Quantity1"><br>
	<button type="submit" name="registration3">Отправить</button><br>
  </form>
<br><br><br>
<div><a href="#top" class="idTop">ВВЕРХ</a></div>
<div class="row" style="height:255px; background-color:#2c3136; margin-top:0;">
	<div class="card" style="width: 15rem;transform:none; background-color:#2c3136; margin-top:5%;border:0px;">
		<img src="./images/logo.png" class="card-img-top" alt="...">
	</div>
	<div class="card" style="width: 17rem;transform:none; background-color:#2c3136; height:20%; border:0px; margin-top:5%;">
		<div class="card-body" style="background-color:#2c3136; color:#c59b49; border:0px;">
			<p class="card-text"><img src="./images/address.png" height="25" width="25">Москва, Набережная 2 оф. 142 <br><br><img src="./images/phone.png" height="25" width="25">+7 923 398 9013</p>
		</div>
	</div>
	<div class="card" style="width: 5rem; background-color:#2c3136; height:15%; margin-top:7%;border:0px;">
		<img src="./images/youtube.png" class="card-img-top" alt="..." style="margin-top:-15%;">
	</div>
	<div class="card" style="width: 5rem; background-color:#2c3136; height:15%; margin-top:7%;border:0px;">
		<img src="./images/instagram.png" class="card-img-top" alt="..." style="margin-top:-15%;">
	</div>
	<div class="card" style="width: 5rem; background-color:#2c3136; height:15%; margin-top:7%;border:0px;">
		<img src="./images/vk.png" class="card-img-top" alt="..." style="margin-top:-15%;">
	</div>
	<div style="text-align:center; color:#c59b49; background-color:#2c3136;">2022 © ShakTour</div>
</div>

</body>
</html>